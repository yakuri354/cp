////
//// Created by yakuri354 on 16.02.2022.
////
//
//#include <iostream>
//#include <vector>
//
//using namespace std;
//using ll = long long;
//
////const ll MAX_N = 1e5;
////
////ll a[MAX_N];
////
////int main() {
////    ll T;
////    cin >> T;
////
////    for (int i = 0; i < T; ++i) {
////        ll N;
////        cin >> N;
////        for (int j = 0; j < N; ++j) {
////            cin >> a[j];
////        }
////        ll maxeven = -1, maxodd = -1;
////        for (int j = 0; j < N; ++j) {
////            if (a[j] % 2 == 0) {
////                if (maxeven > a[j]) {
////                    cout << "NO";
////                    goto next;
////                }
////                maxeven = a[j];
////            } else {
////                if (maxodd > a[j]) {
////                    cout << "NO";
////                    goto next;
////                }
////                maxodd = a[j];
////            }
////        }
////        cout << "YES";
////        next: cout << "\n";
////    }
////}
//
//const ll MAXN = 1e5;
//
//int main() {
////
//}